class Court < ApplicationRecord

  validates_presence_of :name
  has_many :reservations

  def reserved_play_hours(date = Time.now.to_date)
    reservations.where(play_date: date).map(&:play_hour)
  end

  def court_info(date = Time.now.to_date)
    { name: name,
      postcode: postcode,
      format: format,
      surface: surface,
      reserved_hours: reserved_play_hours(date) }
  end

end
