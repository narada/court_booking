class Api::V1::CourtsController < Api::V1::BaseController
  def index
    @courts = Court.where(state: "live")

    render json: { data: {courts: @courts.map(&:court_info)}, status: :ok }
  end
end
