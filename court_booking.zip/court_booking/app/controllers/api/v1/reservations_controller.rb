class Api::V1::ReservationsController < Api::V1::BaseController
  before_action :set_reservation, only: [:show, :update, :destroy]

  def index
    @reservations = @user.reservations

    render json: { data: {reservations: @reservations.to_json(:except => [:created_at, :updated_at])}, status: :ok }
  end

  def show
  end

  def create
    court = Court.find(reservation_params[:court_id])

    if !court.reserved_play_hours(reservation_params[:play_date]).include?(reservation_params[:play_hour].to_i)
      @reservation = @user.reservations.build(reservation_params)
      if @reservation.save
        render json: { message: "successfully created"}, status: :ok
      else
        render json: { message: @reservation.errors.full_messages }, status: :unprocessable_entity
      end
    else
      render json: { message: "Already reserved" }, status: :unprocessable_entity
    end
  end

  def update
    if @reservation.update(reservation_params)
      render json: { message: "successfully updated"}, status: :ok
    else
      render json: { message: @reservation.errors.full_messages }, status: :unprocessable_entity
    end
  end

  def destroy
    if @user.reservations.exists?(@reservation.id)
      @reservation.destroy
      render json: { message: "successfully deleted"}, status: :ok
    else
      render json: { message: "Couldn\'t delete reservation!!!" }, status: :unprocessable_entity
    end
  end

  private

    def set_reservation
      @reservation = Reservation.find(params[:id])
    end

    def reservation_params
      params.require(:reservation).permit(:play_hour, :play_date, :court_id, :note)
    end
end
